package Model.Cards.CardStacks;

import Model.Cards.Card;
import Model.Cards.DealCards.DealCard;

import java.util.ArrayList;

public class PlayerCardStack {
    private ArrayList<DealCard> stack = new ArrayList<DealCard>();

    /**
     * <b> Constructor </b> : Creates new CardStack
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : Creates a new stack that gets Card type objects
     */
    public PlayerCardStack() {
        stack = new ArrayList<DealCard>();
    }

    /**
     * <b> Transformer </b> : Adds a new card to the stack
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : CardStack gets longer with the additions of the new card
     *
     * @param newCard is the card that will be added to the stack
     */

    public void addCard(DealCard newCard) {
        stack.add(newCard);
    }


    public void RemoveCard(int index) {
        stack.remove(index);
    }

    /**
     * <b> Transformer </b> : Removes card form the deck
     * <b> Pre-Conditions </b> : the card must exist in the deck
     * <b> Post-Conditions </b> : removes card from cardstack
     *
     * @param card is the card that will be removed from deck
     */
    public void RemoveCard(Card card) {
        stack.remove(card);
    }



    public ArrayList<String> CardStackTolist() {
        ArrayList<String> arr = new ArrayList<>();
        for (int i = 0; i < stack.size(); i++) {
            arr.add(stack.get(i).getMessage());
        }

        return arr;
    }


    public Card getCard(int index) {
        return stack.get(index);
    }

    public boolean isEmpty() {
        return stack.size() == 0;
    }

    public void ResetCardStack() {
        stack = new ArrayList<DealCard>();
    }

    public DealCard LastCard() {
        return stack.get(stack.size() - 1);
    }


}
