package Model.Cards.CardStacks;

import Model.Cards.Card;
import Model.Cards.DealCards.DealCard;
import Model.Cards.MailCards.MailCard;

import java.util.ArrayList;
import java.util.EmptyStackException;

public class DealCardsStack extends CardStacks{
    private ArrayList<DealCard> Stack;
    private Exception EmptyStackException=new Exception("Deal Card Stack is empty");

    /**
     * <b> Constructor </b> : Creates a new Deal Card stack
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : creates the new stack
     */
    public DealCardsStack(){
        super();
    }

    /**
     * <b> Transformer </b> : takes a card from the stack
     * <b> Pre-Conditions </b> : Stack must not be empty
     * <b> Post-Conditions </b> : pops the card and then putting it at the bottom of the deck
     */
    public DealCard TakeCard() throws Exception{
        DealCard topCard;
        if (Stack.size()==0){throw EmptyStackException;}
        else{
            topCard= Stack.get(0);
            Stack.remove(0);
        }

        return topCard;
    }

    public String[] CardStackToArray() {
        String[] arr=new String[Stack.size()];
        for(int i=0;i<Stack.size();i++){
            arr[i]=Stack.get(i).getMessage();
        }

        return arr;
    }


}
