package Model.Cards.CardStacks;

import Model.Cards.Card;
import Model.Cards.DealCards.DealCard;
import Model.Cards.MailCards.MailCard;

import java.util.ArrayList;

public class MailCardStack extends CardStacks{
    private ArrayList<MailCard> Stack;

    /**
     * <b> Constructor </b> : Creates a stack containing mailcards
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : new stack with deal cards
     */
    public MailCardStack(){
        super();
    }

    /**Μ
     *
     * @param newMailCard is the card that will be added to the stack
     */

}
