package Model.Cards.CardStacks;

import Model.Cards.Card;
import Model.Cards.DealCards.DealCard;

import java.util.ArrayList;
import java.util.Collections;

public class CardStacks {

    private ArrayList<Card> stack;

    public CardStacks() {
    }

    /**
     * <b> Transformer </b> : Shuffles the deck
     * <b> Pre-Conditions </b> : The stack should not be empty
     * <b> Post-Conditions </b> : Rearranges the positions of the cards int the stack
     */

    public void ShuffleDeck() {
        Collections.shuffle(stack);
    }


    /**
     * <b> Transformer </b> : adds a card to the stack
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : adds card to the stack
     */
    public void AddCard(DealCard newCard) {
        stack.add(newCard);
    }

    /**
     * <b> Accessor </b> : Checks if the stack is empty
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : returns true /false depending on the status of the cardstack
     */


    public boolean isEmpty() {
        if (stack.size() == 0) {
            return true;
        } else {
            return false;
        }
    }


}
