package Model.Cards.CardStacks;

import Model.Cards.Card;

import java.util.ArrayList;

public class RejectedCards extends CardStacks{
    private ArrayList<Card> Rejects;
    public void AddToRejects(Card CardToToss){
        Rejects.add(CardToToss);
    }


}
