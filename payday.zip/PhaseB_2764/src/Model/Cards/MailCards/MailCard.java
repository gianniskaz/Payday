package Model.Cards.MailCards;

import Model.Cards.Card;
import Model.Player;
import sun.plugin2.message.Message;

import java.net.URL;

public class MailCard implements Card {
    private int Money;
    private String Message;
    private String ImageURL;

    /**
     * <p> Constructor </p> : Constructs a Mail card
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : Creates new MailCard
     * @param money the price that must be paid or the money the player wins
     * @param Message the message that appears on the card window
     * @param imageURL url for the image of the card
     */
    public MailCard(int money, String Message,String imageURL){

    }

    /**
     * <b> Accessor </b> : Returns the money
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : returns the value of variable Money
     *
     */
    public int getMoney() {
        return Money;
    }

    /**
     * <b> Accessor </b> : Retruns the message
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : Returns the value of the variable message
     *
     */
    public String getMessage(){
        return Message;

    }

    /**
     * <b> Accessor </b> : Return the ImageUrl
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> :Returns image url
     *
     */
    public String getImageUrl() {
        return ImageURL;
    }

    /**
     * Inherited by the other classes
     *
     */
    @Override
    public void CardAction(Player player) {

    }


}
