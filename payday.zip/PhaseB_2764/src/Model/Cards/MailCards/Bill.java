package Model.Cards.MailCards;

import Model.Player;

public class Bill extends MailCard{
    /**
     * <p>constructor</p>:Constructs a Mail card
     *
     * @param money    the price that must be paid or the money the player wins
     * @param Message  the message that appears on the card window
     * @param imageURL url for the image of the card
     */
    public Bill(int money, String Message, String imageURL) {
        super(money, Message, imageURL);
    }

    /**
     * <b> Transformer </b> : The player gives the money to the bank at the end of the month
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : player looses money
     *@param player is the player that draws the card
     */
    @Override
    public void CardAction(Player player) {

    }
}
