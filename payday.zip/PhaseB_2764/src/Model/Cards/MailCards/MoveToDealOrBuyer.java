package Model.Cards.MailCards;

import Model.Player;

public class MoveToDealOrBuyer extends MailCard{
    /**
     * <p>constructor</p>:Constracts a Mail card
     *
     * @param money    the price that must be paid or the money the player wins
     * @param Message  the message that appears on the card window
     * @param imageURL url for the image of the card
     */
    public MoveToDealOrBuyer(int money, String Message, String imageURL) {
        super(money, Message, imageURL);
    }
    /**
     * <b> Transformer </b> :  Player moves to the closest Deal/Buyer position
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> :Players position is changed to closer Deal/Buyer position
     * @param player is the player that draws the card
     */
    @Override
    public void CardAction(Player player) {

    }
}
