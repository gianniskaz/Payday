package Model.Cards.MailCards;


import Model.Player;

public class Ad extends MailCard {


    public Ad(int money, String Message,String ImageUrl) {
        super(money,Message,ImageUrl);

    }

    /**
     * <b> Transformer </b> : Adds 20 euros to players personal money
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : adds money to player using method in player class
     *@param player is the player that draws the card
     */
    @Override
    public void CardAction(Player player) {

    }
}

