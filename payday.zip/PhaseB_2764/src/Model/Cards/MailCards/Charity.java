package Model.Cards.MailCards;

import Model.Player;

public class Charity extends MailCard{
    /**
     * <p>constructor</p>:Constracts a Mail card
     *
     * @param money    the price that must be paid or the money the player wins
     * @param Message  the message that appears on the card window
     * @param imageURL url for the image of the card
     */
    public Charity(int money, String Message, String imageURL) {
        super(money, Message, imageURL);
    }

    /**
     * <b> Transformer </b> : Gives player money to jackpot
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> :gives some money to jackpot and if the player
     * has no money the game gives him a loan
     *@param player is the player that draws the card
     */
    @Override
    public void CardAction(Player player) {

    }
}
