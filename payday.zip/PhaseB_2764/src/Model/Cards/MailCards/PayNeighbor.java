package Model.Cards.MailCards;

import Model.Player;

public class PayNeighbor extends MailCard{
    /**
     * <p>constructor</p>:Constructs a Mail card
     *
     * @param money    the price that must be paid or the money the player wins
     * @param Message  the message that appears on the card window
     * @param imageURL url for the image of the card
     */
    public PayNeighbor(int money, String Message, String imageURL) {
        super(money, Message, imageURL);
    }

    /**
     * <b> Transformer </b> :  Player gives opponent money
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : money go to opponent and if needed player gets loan
     * @param player is the player that draws a card
     */
    @Override
    public void CardAction(Player player) {
        if (player.getMoney()<getMoney()){
            player.AddLoan(getMoney());
        }
        else{
            player.getOpponent().GiveOrTakeMoney(getMoney());
            player.GiveOrTakeMoney(getMoney()*(-1));
        }

    }
}
