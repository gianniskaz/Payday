package Model.Cards;

import Model.Player;

public interface Card {

    String getMessage();

    String getImageUrl();

    int getMoney();

    void CardAction(Player player);
}
