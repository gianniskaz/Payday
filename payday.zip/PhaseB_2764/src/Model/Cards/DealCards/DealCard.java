package Model.Cards.DealCards;


import Model.Cards.Card;
import Model.Player;

import java.awt.*;

public class DealCard implements Card {
    private int Money;
    private String Message;
    private int price;
    /**
     * <p> Constructor </p> : Constructs a Mail card
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : Creates new MailCard
     * @param money the price that must be paid or the money the player wins
     * @param Message the message that appears on the card window
     * @param price is the value of the card if sold
     *
     */
    public DealCard(int money, String Message,int price){
        Money=money;
        this.Message=Message;
        this.price=price;
    }

    /**
     * <b> Accessor </b> : Returns the money
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : returns the value of variable Money
     *
     */
    public int getMoney() {
        return Money;
    }

    /**
     * <b> Accessor </b> : Returns the message
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : Returns the value of the variable message
     *
     */
    public String getMessage(){
        return Message;

    }

    @Override
    public String getImageUrl() {
        return null;
    }

    /**
     * <b> Accessor </b> : Return the ImageUrl
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> :Returns image url
     *
     */
    public int getPrice() {
        return price;
    }

    /**
     * Inherited by the other classes
     *
     */
    @Override
    public void CardAction(Player player) {


    }

}
