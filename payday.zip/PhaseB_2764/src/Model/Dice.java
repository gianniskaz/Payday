package Model;

import java.util.Random;

public class Dice {
    private int CurrentDiceNumber;

    /**
     * <b> Constructor </b> : Initializes the Dice
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : Creates the dice
     */
    public Dice(){

    }

    /**
     * <b> Accessor </b> : Gives the number of the dice
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> :returns DiceNumber
     */
    public int getRoll(){
        return CurrentDiceNumber;
    }

    /**
     * <b> Transformer </b> : Rolls the dice number
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : rolls and sets the value of the CurrentDiceNumber
     */
    public void RollDice(){
        Random rand=new Random();
        int DiceNumber=rand.nextInt(6)+1;
        CurrentDiceNumber=DiceNumber;
    }
}
