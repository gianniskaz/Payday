package Model;

public class Jackpot {
    private static int Loot;

    /**
     * <b> Constructor </b> : Creates a new Jackpot
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : new Jackpot the value of the loot is set to zero
     */
    public Jackpot() {

    }

    /**
     * <b> Accessor </b> : Returns the value of the current Jackpot
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : returns loot
     */
    public static int getLoot() {
        return Loot;
    }

    public int getintLoot() {
        return Loot;
    }

    /**
     * <b> Transformer </b> : adds more money to the jackpot
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : adds money to loot
     */
    public void AddLoot(int loot) {
        Loot += loot;
    }

    /**
     * <b> Transformer </b> : sets the price of the loot
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : sets new jackpot i ll use it to reset the loot to
     * zero if a player wins the jackpot
     */
    public void setLoot(int loot) {
        Loot = loot;
    }
}
