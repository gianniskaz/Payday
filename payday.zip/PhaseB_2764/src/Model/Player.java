package Model;

import Model.Cards.*;
import Model.Cards.CardStacks.PlayerCardStack;
import Model.Cards.DealCards.DealCard;

public class Player {
    private int Money;
    private String name;
    private int Loan;
    public PlayerCardStack plrCards;
    private int CurrentPosition;
    private int NumberOfWins;
    private int NumberOfMonthsRemaining;
    private boolean turn;
    private Player opponent;
    private int Bills;
    private boolean finishedTurn;
    private boolean rolled;

    /**
     * <b> Accessor </b> : returns the player-opponent
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> :
     */
    public Player getOpponent() {
        return opponent;
    }

    /**
     * <b> Transformer </b> : sets the opponent of the player
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> :
     */
    public void setOpponent(Player opponent1) {
        opponent = opponent1;
    }

    /**
     * <b> Constructor </b> : Creates a new player
     * <b> Pre-Conditions </b>:None
     * <b> Post-Conditions </b>: Creates player and sets money, name etc.
     *
     * @param name is the name of the player
     */
    public Player(String name) {
        this.name = name;
        plrCards = new PlayerCardStack();
        finishedTurn = false;
        rolled = false;
    }

    /**
     * <b> Transformer </b> : Adds money to the loan
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : adds multiples of 1000 depending on the money needed
     */
    public void AddLoan(int LoanedMoney) {
        double MoneyToLoan;
        MoneyToLoan = Math.ceil(LoanedMoney / 1000) * 1000 + 1000;
        Loan += (int) MoneyToLoan;
    }


    /**
     * <b> Accessor </b> : Returns the name of the player
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : returns a String with the name of the player
     */

    public String getName() {
        return name;
    }

    /**
     * <b> Transformer</b> : Sets the name of the player
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : Changes the String name to newName
     */

    public void setName(String newName) {
        name = newName;

    }

    /**
     * <b> Accessor </b> : Returns the value of the variable Money
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : returns money
     */
    public int getMoney() {
        return Money;
    }

    /**
     * <b> Transformer </b> : sets the value of the variable Money
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : sets the value of Money
     */
    public void setMoney(int newMoney) {
        Money = newMoney;
    }

    /**
     * <b> Transformer </b> : changes the value of the players loan
     * <b> Pre-Conditions </b>: None
     * <b> Post-Conditions </b> : Gives loan to the player
     *
     * @param newLoan is the money that will be the players loan
     */
    public void setLoan(int newLoan) {
        Loan = newLoan;
    }

    /**
     * <b> Accessor </b> : Returns the value of the variable Loan
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : return value of Loan
     */
    public int getLoan() {
        return Loan;
    }

    /**
     * <b> Transformer </b> : Changes the value of money
     * <b> Pre-Conditions </b> :  None
     * <b> Post-Conditions </b> : adds or removes money from the players cash and gives
     * and gives lawn if needed, meaning that it will call the giveLawn() function
     */
    public void GiveOrTakeMoney(int money) {
        while (money + getMoney() < 0) {
            setLoan(Loan + 1000);
            Money += 1000;
        }
        Money += money;
    }

    /**
     * <b> Transformer </b> : adds the card to the CardStack
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : adds card to CardStack
     *
     * @param newCard is the card that will be added to the CardStack
     */
    public void addCardToStack(DealCard newCard) {
        plrCards.addCard(newCard);
    }

    /**
     * <b> Observer </b> : returns if the player has finished his turn
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : boolean true or false depending on the players status
     */
    public boolean hasFinished() {
        return finishedTurn;
    }

    /**
     * <b> Transformer </b> : Sells card
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : Removes card from CardStack and gives the money to the player
     *
     * @param CardToSell the card that the player sells
     */
    public void SellCard(Card CardToSell) {
        plrCards.RemoveCard(CardToSell);
        Money += CardToSell.getMoney();

    }

    /**
     * <b> Accessor </b> : Returns the position of the player
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : Returns int (meaning the day of the month the player is at)
     */
    public int getPosition() {
        return CurrentPosition;
    }

    /**
     * <b> Transformer </b> : Moves player to new position
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : changes the position of the player
     *
     * @param steps is the number of tiles the player will move
     */

    public void setPosition(int steps) {
        CurrentPosition += steps;
    }

    /**
     * <b> Accessor </b>: returns players score
     * <b> Pre-Conditions </b>:None
     * <b> Post-Conditions </b>: return players NumberOfWins
     */
    public int getScore() {
        return NumberOfWins;
    }

    /**
     * <b> Accessor </b>: overriding method to string
     * <b> Pre-Conditions </b>:None
     * <b> Post-Conditions </b>: returns the name of the player and their score
     */
    @Override
    public String toString() {
        return getName();
    }

    /**
     * <b> Accessor </b>: returns true if the player has reached the end of the month otherwise returns false
     * <b> Pre-Conditions </b>:None
     * <b> Post-Conditions </b>: returns True/false depending on players round status
     */
    public boolean hasFinishedMonth() {
        return CurrentPosition == 31;
    }

    /**
     * <b> Transformer </b>: sets the number of months remaining
     * <b> Pre-Conditions </b>:None
     * <b> Post-Conditions </b>: sets the value of parameter NumberOfMonthsRemaining
     */
    public void setNumberOfMonthsRemaining(int numberOfMonths) {
        NumberOfMonthsRemaining = numberOfMonths;
    }

    /**
     * <b> Accessor </b>: returns the value of parameter NumberOfMonthsRemaining
     * <b> Pre-Conditions </b>:None
     * <b> Post-Conditions </b>: returns the value of parameter NumberOfMonthsRemaining
     */
    public int getNumberOfMonthsRemaining() {
        return NumberOfMonthsRemaining;
    }

    /**
     * <b> Accessor </b>: returns true if it is players turn
     * <b> Pre-Conditions </b>:None
     * <b> Post-Conditions </b>: returns True/false depending on players turn
     */
    public boolean getTurn() {
        return turn;
    }

    /**
     * <b> Transformer </b>: changes the value of turn parameter
     * <b> Pre-Conditions </b>:None
     * <b> Post-Conditions </b>: changes the value of turn parameter
     */
    public void setTurn(boolean turn) {
        this.turn = turn;
    }


    /**
     * <b> Transformer </b>: adds money to the bill
     * <b> Pre-Conditions </b>:None
     * <b> Post-Conditions </b>: changes the value of bills parameter
     */
    public void addBill(int Bill) {
        Bills += Bill;
    }


    /**
     * <b> Transformer </b>: changes the value of bills parameter
     * <b> Pre-Conditions </b>:None
     * <b> Post-Conditions </b>: changes the value of bills parameter
     * @param newBill is the amount of money the  bill will be set to have
     */
    public void setBill(int newBill) {
        Bills = newBill;
    }


    /**
     * <b> Observer </b>: returns the value of bills
     * <b> Pre-Conditions </b>:None
     * <b> Post-Conditions </b>:
     */
    public int getBill() {
        return Bills;
    }
    /**
     * <b> Observer </b>: returns the cards of the player
     * <b> Pre-Conditions </b>:None
     * <b> Post-Conditions </b>:
     */
    public PlayerCardStack PlayerCards() {
        return plrCards;
    }

    /**
     * <b> Transformer </b>: changes the value of finishedTurn
     * <b> Pre-Conditions </b>:None
     * <b> Post-Conditions </b>: changes the value of finished parameter
     *
     * @param finished true or false depending on turn
     */
    public void setFinishedTurn(boolean finished) {
        finishedTurn = finished;

    }

    /**
     * <b> Transformer </b>: returns the value of finishedTurn
     * <b> Pre-Conditions </b>:None
     * <b> Post-Conditions </b>:
     */
    public boolean getFinishedTurn() {
        return finishedTurn;
    }

    /**
     * <b> Observer </b>: returns true if the player has rolled the dice and the opposite
     * <b> Pre-Conditions </b>:None
     * <b> Post-Conditions </b>:
     *
     */
    public boolean hasRolled() {
        return rolled;
    }


    /**
     * <b> Transformer </b>: changes the value of hasrolled parameter
     * <b> Pre-Conditions </b>:None
     * <b> Post-Conditions </b>: changes the value of turn parameter
     * @param hasrolled true or false depending on the players status
     */
    public void sethasRolled(boolean hasrolled) {
        this.rolled = hasrolled;
    }
}
