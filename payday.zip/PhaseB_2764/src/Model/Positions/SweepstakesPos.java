package Model.Positions;

public class SweepstakesPos extends Position{
    /**
     * <b> Constructor </b> : Creates new SweepstakesPosition
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : new SweepstakesPosition
     * @param imageUrl       is the images url that will be put in the card
     * @param PositionNumber the number 1-30 meaning the days of the month
     */
    public SweepstakesPos(String imageUrl, int PositionNumber) {
        super(imageUrl, PositionNumber);
    }
}
