package Model.Positions;

public abstract class Position {
    private String imageUrl;
    private int PositionNumber;
    public static String dayName;
    private  String daysWeek[] = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday","Saturday","Sunday"};
    private int CurrentWeekDay=0;

    /**
     * <b> Constructor </b> : Creates new position
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : new position and sets the name of the day
     * @param imageUrl is the images url that will be put in the card
     * @param PositionNumber the number 1-31 meaning the days of the month
     */
    public Position(String imageUrl,int PositionNumber){
        this.imageUrl=imageUrl;
        this.PositionNumber=PositionNumber;
        if (CurrentWeekDay==7){
            CurrentWeekDay=1;
        }
        else{
            CurrentWeekDay++;
        }

        dayName=daysWeek[CurrentWeekDay];
    }

    /**
     * <b> Accessor </b> : returns the position
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : returns the value of the PositionNumber variable
     */
    public int getPosition() {
        return PositionNumber;
    }


    /**
     * <b> Transformer </b> : Sets the position
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : Sets a value at the PositionNumber
     */
    public void setPosition(int newPosition){
        PositionNumber=newPosition;

    }


    public static String  getDayName(){
        return dayName;
    }

    public String getImageUrl(){
        return imageUrl;
    }


}
