package Model.Positions;

public class MessagePos extends Position{
    private int NumberOfMessages;
    /**
     * <b> Constructor </b> : Creates new MessagePosition
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : new MessagePosition
     * @param imageUrl       is the images url that will be put in the card
     * @param PositionNumber the number 1-30 meaning the days of the month
     * @param NumberOfMessages is the number of cards the player must draw
     */
    public MessagePos(String imageUrl, int PositionNumber,int NumberOfMessages) {
        super(imageUrl, PositionNumber);
    }

    /**
     * <b> Accessor </b> : Returns how many cards the player should draw
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : Returns NumberOfMessages
     */
    public void CardsToDraw(){

    }
}
