package Model.Positions;

public class YardSalePos extends Position{
    /**
     * <b> Constructor </b> : Creates new YardSalePosition
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : new YardSalePosition
     * @param imageUrl       is the images url that will be put in the card
     * @param PositionNumber the number 1-30 meaning the days of the month
     */
    public YardSalePos(String imageUrl, int PositionNumber) {
        super(imageUrl, PositionNumber);
    }
}
