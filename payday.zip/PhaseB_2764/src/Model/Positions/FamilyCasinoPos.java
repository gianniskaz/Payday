package Model.Positions;

public class FamilyCasinoPos extends Position{
    /**
     * <b> Constructor </b> : Creates new FamilyCasinoPosition
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : new FamilyCasinoPosition
     *
     * @param imageUrl       is the images url that will be put in the card
     * @param PositionNumber the number 1-30 meaning the days of the month
     */
    public FamilyCasinoPos(String imageUrl, int PositionNumber) {
        super(imageUrl, PositionNumber);
    }
}
