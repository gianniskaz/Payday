package Model.Positions;

public class StartPos extends Position{
    /**
     * <b> Constructor </b> : Creates new position
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : new position and sets the name of the day
     *
     * @param imageUrl       is the images url that will be put in the card
     *
     */
    public StartPos(String imageUrl) {
        super(imageUrl, 0);
    }
}
