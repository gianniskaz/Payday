package Model.Positions;

public class PayDayPosition extends Position{
    /**
     * <b> Constructor </b> : Creates new position
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : new position and sets the name of the day
     *
     * @param imageUrl       is the images url that will be put in the card
     *
     */
    public PayDayPosition(String imageUrl) {
        super(imageUrl, 31);
    }
}
