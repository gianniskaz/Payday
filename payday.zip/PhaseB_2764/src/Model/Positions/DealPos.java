package Model.Positions;

public class DealPos extends Position{
    /**
     * <b> Constructor </b> : Creates new DealPosition
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> : new DealPosition
     *
     * @param imageUrl       is the images url that will be put in the card
     * @param PositionNumber the number 1-30 meaning the days of the month
     */
    public DealPos(String imageUrl, int PositionNumber) {

        super(imageUrl, PositionNumber);
    }
}
