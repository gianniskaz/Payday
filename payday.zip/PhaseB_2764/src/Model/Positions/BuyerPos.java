package Model.Positions;

public class BuyerPos extends Position{


    /**
     * <b> Constructor </b> : Creates new BuyerPosition
     * <b> Pre-Conditions </b> : None
     * <b> Post-Conditions </b> :new BuyerPosition
     *
     * @param imageUrl       is the images url that will be put in the card
     * @param PositionNumber the number 1-30 meaning the days of the month
     */
    public BuyerPos(String imageUrl, int PositionNumber) {
        super(imageUrl, PositionNumber);
    }
}
