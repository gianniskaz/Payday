package View;

public class RunPayDay {
    public static void main(String args[]){
        GUI StarGame=new GUI();

    }
}
