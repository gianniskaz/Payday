package View;

import Controller.Controller;
import Model.Cards.DealCards.DealCard;
import Model.Cards.MailCards.MailCard;
import Model.Jackpot;
import Model.Player;
import Model.Positions.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.Random;

public class GUI extends JFrame {
    private Controller game;
    private JDesktopPane Player1;
    private JDesktopPane Player2;
    private JDesktopPane Board;
    private JDesktopPane Jackpot;
    private JPanel Dice1;
    private JPanel Dice2;
    private JTextArea InfoBox;
    private JButton RollDice1;
    private JButton MyDealCards1;
    private JButton GetLoan1;
    private JButton EndTurn1;
    private JButton RollDice2;
    private JButton MyDealCards2;
    private JButton GetLoan2;
    private JButton EndTurn2;
    private JButton MailCardButton;
    private JButton DealCardButton;
    private JLayeredPane MainPanel;
    private JFrame MainFrame;
    private JLabel PawnA;
    private JLabel PawnB;
    public ClassLoader cldr;
    PayDayCards Cards;
    private Player plr1;
    private Player plr2;
    private JTextField Money1;
    private JTextField Money2;
    private JTextField Loan1;
    private JTextField Loan2;
    private JTextField Bills1;
    private JTextField Bills2;
    private JTextField JackpotText;
    private Position[] board;
    private int position1;
    private int position2;
    private int diceRoll1;
    private int diceRoll2;
    private int NumbersOfMonthsRemaining;


    /**
     * <b>Constructor</b>:Creates a new Window with panels and buttons<br />
     * <b>Post-Conditions</b>: New window and panels.
     */

    public GUI() {
        cldr = this.getClass().getClassLoader();
        game = new Controller();
        Player1 = new JDesktopPane();
        Player2 = new JDesktopPane();
        Board = new JDesktopPane();
        InfoBox = new JTextArea();
        RollDice1 = new JButton();
        MyDealCards1 = new JButton();
        GetLoan1 = new JButton();
        EndTurn1 = new JButton();
        RollDice2 = new JButton();
        MyDealCards2 = new JButton();
        GetLoan2 = new JButton();
        EndTurn2 = new JButton();
        Dice1 = new JPanel();
        Dice2 = new JPanel();
        MailCardButton = new JButton();
        DealCardButton = new JButton();
        Jackpot = new JDesktopPane();
        PawnA = new JLabel();
        PawnB = new JLabel();
        Cards = new PayDayCards();
        plr1 = game.Player1;
        plr2 = game.Player2;
        position1 = 0;
        position2 = 0;
        diceRoll1 = 0;
        diceRoll2 = 0;
        Object[] possibilities = new Object[100];
        for (int i = 0; i < possibilities.length; i++) {
            possibilities[i] = i + 1;
        }
        int s = (int) JOptionPane.showInputDialog(
                null,
                "Input the amount of months (rounds) this match will last: ",
                "START",
                JOptionPane.PLAIN_MESSAGE,
                null,
                possibilities,
                null);
        NumbersOfMonthsRemaining = s;


        MainFrame = new JFrame("PayDay");
        MainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        MainFrame.setSize(new Dimension(1500, 1000));
        MainFrame.setLayout(null);
        MainFrame.setVisible(true);

        MainPanel = new JDesktopPane();
        MainPanel.setBackground(new Color(5, 102, 8));
        MainPanel.setVisible(true);
        MainPanel.setBounds(0, 0, 1500, 1000);
        MainFrame.getContentPane().add(MainPanel);
        initComponents();


    }

    /**
     * <b> Transformer </b>: Creates some buttons and labels inside the main window
     * <b> Pre-Conditions </b>:None
     * <b> Post-Conditions </b>: buttons and labels in main window
     * such as infobox, player panels, buttons in player panels
     */
    public void initComponents() {
        Color green = new Color(5, 102, 8);
        game.SetFirstPlayer();
        board();
        PlayerPanels();
        plr1.setNumberOfMonthsRemaining(NumbersOfMonthsRemaining);
        plr2.setNumberOfMonthsRemaining(NumbersOfMonthsRemaining);


        //infobox
        InfoBox.setBackground(Color.white);
        InfoBox.setBounds(1075, 350, 350, 125);
        InfoBox.setVisible(true);
        InfoBox.setText("Info Box" + "\n" + game.Player1.getNumberOfMonthsRemaining() + " Months Remaining" + "\n" + "Turn: " + game.Turn());
        InfoBox.setEditable(false);
        MainPanel.add(InfoBox);

        //mailcards
        Image MailCardImg = new ImageIcon(cldr.getResource("resources/images/mailCard.png")).getImage();
        MailCardImg = MailCardImg.getScaledInstance(175, 100, Image.SCALE_SMOOTH);
        MailCardButton.setIcon(new ImageIcon(MailCardImg));
        MailCardButton.addActionListener(new MailCardListener());
        MainPanel.add(MailCardButton);
        MailCardButton.setSize(100, 50);
        MailCardButton.setBounds(1075, 500, 175, 100);
        MailCardButton.setEnabled(false);


        //dealcards
        ImageIcon DealCardIcon = new ImageIcon(cldr.getResource("resources/images/dealCard.png"));
        DealCardButton.setIcon(DealCardIcon);
        DealCardButton.addActionListener(new DealCardListener());
        MainPanel.add(DealCardButton);
        DealCardButton.setSize(100, 50);
        DealCardButton.setBounds(1275, 500, 175, 100);
        DealCardButton.setEnabled(false);


        //Jackpot tile
        JPanel pic = new JPanel();
        JackpotText = new JTextField();
        Image img = new ImageIcon(cldr.getResource("resources/images/jackpot.png")).getImage();
        img = img.getScaledInstance(200, 80, img.SCALE_SMOOTH);
        pic.add(new JLabel(new ImageIcon(img)));
        pic.setVisible(true);
        JackpotText.setText("Jackpot: " + Model.Jackpot.getLoot() + " Euro");
        MainPanel.add(JackpotText, JLayeredPane.POPUP_LAYER);
        JackpotText.setSize(new Dimension(200, 20));
        JackpotText.setLocation(600, 960);
        JackpotText.setEditable(false);
        JackpotText.setBorder(null);
        JackpotText.setVisible(true);
        JackpotText.setBackground(green);
        JackpotText.setForeground(Color.white);


        JPanel JackpotPic = new JPanel();
        JackpotPic.add(pic);
        JackpotPic.setVisible(true);
        JackpotPic.setSize(200, 100);
        MainPanel.add(JackpotPic, JLayeredPane.POPUP_LAYER);
        JackpotPic.setLocation(600, 850);


        //dices
        Dice1 = CreateDice(1);
        Dice2 = CreateDice(1);
        MainPanel.add(Dice1, JLayeredPane.POPUP_LAYER);
        MainPanel.add(Dice2, JLayeredPane.POPUP_LAYER);
        Dice1.setLocation(1300, 200);
        Dice2.setLocation(1300, 825);
        Dice1.setVisible(true);
        Dice2.setVisible(true);


        //Pawns
        PawnA = CreatePlayerPawnA();
        PawnA.setVisible(true);
        PawnB = CreatePlayerPawnB();
        PawnB.setVisible(true);
        MainPanel.add(PawnA, JLayeredPane.POPUP_LAYER);
        MainPanel.add(PawnB, JLayeredPane.POPUP_LAYER);
        PawnB.setLocation(50, 250);
        PawnA.setLocation(50, 250);
        MainPanel.repaint();

        MainPanel.repaint();
        MainFrame.pack();
        MainFrame.setVisible(true);
        MainFrame.setExtendedState(java.awt.Frame.MAXIMIZED_BOTH);


    }

    /**
     * <b> Transformer </b>: Creates dice image with current roll
     * <b> Pre-Conditions </b>:None
     * <b> Post-Conditions </b>: label
     *
     */

    public JPanel CreateDice(int num) {
        JPanel dice = new JPanel();
        dice.setSize(60, 60);
        dice.setBackground(Color.black);
        if (num == 1) {
            Image num1 = new ImageIcon(cldr.getResource("resources/images/dice-1.jpg")).getImage();
            num1 = num1.getScaledInstance(50, 50, num1.SCALE_SMOOTH);
            dice.add(new JLabel(new ImageIcon(num1)));

        } else if (num == 2) {
            Image num2 = new ImageIcon(cldr.getResource("resources/images/dice-2.jpg")).getImage();
            num2 = num2.getScaledInstance(50, 50, num2.SCALE_SMOOTH);
            dice.add(new JLabel(new ImageIcon(num2)));

        } else if (num == 3) {
            Image num3 = new ImageIcon(cldr.getResource("resources/images/dice-3.jpg")).getImage();
            num3 = num3.getScaledInstance(50, 50, num3.SCALE_SMOOTH);
            dice.add(new JLabel(new ImageIcon(num3)));

        } else if (num == 4) {
            Image num4 = new ImageIcon(cldr.getResource("resources/images/dice-4.jpg")).getImage();
            num4 = num4.getScaledInstance(50, 50, num4.SCALE_SMOOTH);
            dice.add(new JLabel(new ImageIcon(num4)));

        } else if (num == 5) {
            Image num5 = new ImageIcon(cldr.getResource("resources/images/dice-5.jpg")).getImage();
            num5 = num5.getScaledInstance(50, 50, num5.SCALE_SMOOTH);
            dice.add(new JLabel(new ImageIcon(num5)));

        } else if (num == 6) {
            Image num6 = new ImageIcon(cldr.getResource("resources/images/dice-6.jpg")).getImage();
            num6 = num6.getScaledInstance(50, 50, num6.SCALE_SMOOTH);
            dice.add(new JLabel(new ImageIcon(num6)));

        }

        dice.setVisible(true);
        dice.setBorder(null);
        return dice;
    }

    /**
     * <b> Transformer </b>: Creates the panels of players and their contents
     * <b> Pre-Conditions </b>:None
     * <b> Post-Conditions </b>: label
     *
     */

    public void PlayerPanels() {


        Money1 = new JTextField("Money: " + plr1.getMoney() + " Euro");
        Money1.setEditable(false);
        Money1.setOpaque(false);
        Money1.setBorder(null);

        Money2 = new JTextField("Money: " + plr2.getMoney() + " Euro");
        Money2.setEditable(false);
        Money2.setOpaque(false);
        Money2.setBorder(null);


        Loan1 = new JTextField("Loan: " + plr1.getLoan() + " Euro");
        Loan1.setEditable(false);
        Loan1.setOpaque(false);
        Loan1.setBorder(null);


        Loan2 = new JTextField("Loan: " + plr2.getLoan() + " Euro");
        Loan2.setEditable(false);
        Loan2.setOpaque(false);
        Loan2.setBorder(null);


        Bills1 = new JTextField("Bills: " + plr1.getBill() + " Euro");
        Bills1.setEditable(false);
        Bills1.setOpaque(false);
        Bills1.setBorder(null);


        Bills2 = new JTextField("Bills: " + plr2.getBill() + " Euro");
        Bills2.setEditable(false);
        Bills2.setOpaque(false);
        Bills2.setBorder(null);


        JLabel PlayerName1 = new JLabel();
        PlayerName1.setText(game.Player1.getName());
        JLabel PlayerName2 = new JLabel();
        PlayerName2.setText(game.Player2.getName());


        RollDice1.setText("Roll Dice");
        RollDice1.addActionListener(new RollDiceListener1());
        EndTurn1.setText("End Turn");
        EndTurn1.addActionListener(new EndTurnListener1());
        GetLoan1.setText("Get Loan");
        GetLoan1.addActionListener(new GetLoanListener1());
        MyDealCards1.setText("My Deal Cards");
        MyDealCards1.addActionListener(new MyDealCardsListener1());

        RollDice2.setText("Roll Dice");
        RollDice2.addActionListener(new RollDiceListener2());
        EndTurn2.setText("End Turn");
        EndTurn2.addActionListener(new EndTurnListener2());
        GetLoan2.setText("Get Loan");
        GetLoan2.addActionListener(new GetLoanListener2());
        MyDealCards2.setText("My Deal Cards");
        MyDealCards2.addActionListener(new MyDealCardsListener2());


        //PLAYER2
        Player2.setSize(new Dimension(350, 300));
        Player2.setBounds(1075, 650, 350, 300);
        Player2.setLayout(null);
        Player2.add(PlayerName2);
        PlayerName2.setSize(350, 15);
        PlayerName2.setLocation(10, 10);
        Player2.add(Money2);
        Money2.setSize(350, 15);
        Money2.setLocation(10, 50);
        Player2.add(Loan2);
        Loan2.setSize(100, 10);
        Loan2.setLocation(10, 90);
        Player2.add(Bills2);
        Bills2.setSize(100, 10);
        Bills2.setLocation(10, 130);
        Player2.add(RollDice2);
        RollDice2.setSize(150, 30);
        RollDice2.setLocation(10, 180);
        Player2.add(MyDealCards2);
        MyDealCards2.setSize(150, 30);
        MyDealCards2.setLocation(10, 220);
        Player2.add(GetLoan2);
        GetLoan2.setSize(150, 30);
        GetLoan2.setLocation(10, 260);
        Player2.add(EndTurn2);
        EndTurn2.setSize(150, 30);
        EndTurn2.setLocation(170, 260);

        MainPanel.add(Player2);

        //PLAYER1
        Player1.setSize(350, 300);
        Player1.setBounds(1075, 25, 350, 300);
        Player1.setLayout(null);
        Player1.setVisible(true);
        Player1.add(PlayerName1);
        PlayerName1.setSize(350, 15);
        PlayerName1.setLocation(10, 10);
        Player1.add(Money1);
        Money1.setSize(350, 15);
        Money1.setLocation(10, 50);
        Player1.add(Loan1);
        Loan1.setSize(100, 10);
        Loan1.setLocation(10, 90);
        Player1.add(Bills1);
        Bills1.setSize(100, 10);
        Bills1.setLocation(10, 130);
        Player1.add(RollDice1);
        RollDice1.setSize(150, 30);
        RollDice1.setLocation(10, 180);
        Player1.add(MyDealCards1);
        MyDealCards1.setSize(150, 30);
        MyDealCards1.setLocation(10, 220);
        Player1.add(GetLoan1);
        GetLoan1.setSize(150, 30);
        GetLoan1.setLocation(10, 260);
        Player1.add(EndTurn1);
        EndTurn1.setSize(150, 30);
        EndTurn1.setLocation(170, 260);
        MainPanel.add(Player1);


    }

    /**
     * <b> Transformer </b>: Creates the board with the tiles
     * <b> Pre-Conditions </b>:None
     * <b> Post-Conditions </b>: label
     *
     */

    public void board() {
        Color green = new Color(5, 102, 8);
        Board.setBackground(green);
        Board.setBounds(0, 200, 1000, 800);
        Board.setVisible(true);
        JPanel logo = new JPanel();
        MainPanel.add(logo);
        logo.setBounds(0, 0, 1000, 200);
        logo.setVisible(true);
        Image logoImg = new ImageIcon(cldr.getResource("resources/images/logo.png")).getImage();
        logoImg = logoImg.getScaledInstance(1000, 200, Image.SCALE_SMOOTH);
        logo.add(new JLabel(new ImageIcon(logoImg)));
        board = game.init_board();
        String daysWeek[] = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
        for (int i = 0; i < board.length; i++) {
            JPanel tile = new JPanel();
            JPanel pic = new JPanel();
            JTextField DayName = new JTextField();
            DayName.setBackground(Color.YELLOW);
            String ImageURL = board[i].getImageUrl();
            tile.setSize(100, 50);
            Image picImg = new ImageIcon(cldr.getResource(ImageURL)).getImage();
            picImg = picImg.getScaledInstance(100, 100, Image.SCALE_SMOOTH);
            pic.add(new JLabel(new ImageIcon(picImg)));
            DayName.setText(daysWeek[i % 7] + " " + i);
            if (i == 0) {
                DayName.setText("Start");
            }
            DayName.setEditable(false);
            DayName.setVisible(true);
            pic.setVisible(true);
            tile.add(DayName);
            tile.add(pic);
            tile.setBackground(green);
            DayName.setSize(100, 20);
            DayName.setLocation(0, 0);
            pic.setSize(100, 80);
            pic.setLocation(0, 20);
            tile.setVisible(true);
            Board.add(tile);
        }
        Board.setLayout(new GridLayout(0, 7));
        Board.setVisible(true);
        MainPanel.add(Board);


    }


    /**
     * a class which is used for doing some action after MailCard button has been pushed
     */
    private class MailCardListener implements ActionListener {

        /**
         * <b> Transformer </b> : Performing the action
         * <b> Pre Conditions </b> : None
         * <b> Post-Conditions </b> : performing the action
         */

        @Override
        public void actionPerformed(ActionEvent e) {
            Cards.setVisible(true);
            Cards.readFile("resources/dealCards_greeklish.csv", "Deal");
            Cards.readFile("resources/mailCards.csv", "Mail");
            int x = new Random().nextInt(48);// for Random

            if (Cards.mailCardCount == 48) {
                Cards.mailCardCount = 0;
            }
            Cards.showMailCard(x);
            String MailCardType = Cards.mailCards[x][1];
            if (game.Player1.getTurn() == true) {


                if (MailCardType.equals("Charity")) {
                    int price = Integer.parseInt(Cards.mailCards[x][4]);
                    plr1.GiveOrTakeMoney(-1 * price);
                    game.jp.AddLoot(price);
                } else if (MailCardType.equals("Αdvertisement")) {
                    int price = Integer.parseInt(Cards.mailCards[x][4]);
                    plr1.GiveOrTakeMoney(price);
                } else if (MailCardType.equals("PayTheNeighbor")) {
                    int price = Integer.parseInt(Cards.mailCards[x][4]);
                    plr1.GiveOrTakeMoney(-1 * price);
                    plr1.getOpponent().GiveOrTakeMoney(price);
                } else if (MailCardType.equals("MadMoney")) {
                    int price = Integer.parseInt(Cards.mailCards[x][4]);
                    plr1.GiveOrTakeMoney(price);
                    plr1.getOpponent().GiveOrTakeMoney(-1 * price);
                } else if (MailCardType.equals("Bill")) {
                    int price = Integer.parseInt(Cards.mailCards[x][4]);
                    plr1.addBill(price);
                } else if (MailCardType.equals("MoveToDealBuyer")) {
                    Position CurrentPos = GetPawnPosition("PawnA");
                    int i = position1;
                    while (!(board[i] instanceof DealPos) & !(board[i] instanceof BuyerPos)) {
                        i += 1;
                    }
                    MovePawnA(i - position1);

                }


            } else {
                if (MailCardType.equals("Charity")) {
                    int price = Integer.parseInt(Cards.mailCards[x][4]);
                    plr2.GiveOrTakeMoney(-1 * price);
                    game.jp.AddLoot(price);
                } else if (MailCardType.equals("Αdvertisement")) {
                    int price = Integer.parseInt(Cards.mailCards[x][4]);
                    plr2.GiveOrTakeMoney(price);
                } else if (MailCardType.equals("PayTheNeighbor")) {
                    int price = Integer.parseInt(Cards.mailCards[x][4]);
                    plr2.GiveOrTakeMoney(-1 * price);
                    plr2.getOpponent().GiveOrTakeMoney(price);
                } else if (MailCardType.equals("MadMoney")) {
                    int price = Integer.parseInt(Cards.mailCards[x][4]);
                    plr2.GiveOrTakeMoney(price);
                    plr2.getOpponent().GiveOrTakeMoney(-1 * price);
                } else if (MailCardType.equals("Bill")) {
                    int price = Integer.parseInt(Cards.mailCards[x][4]);
                    plr2.addBill(price);
                } else if (MailCardType.equals("MoveToDealBuyer")) {
                    Position CurrentPos = GetPawnPosition("PawnB");
                    int i = position2;
                    while (!(board[i] instanceof DealPos) & !(board[i] instanceof BuyerPos)) {
                        i += 1;
                    }
                    MovePawnB(i - position2);

                }


            }

            MailCardButton.setEnabled(false);

            repaintPlayerPanels();
            JackpotText.setText("Jackpot: " + game.jp.getLoot() + " Euro");

        }

    }

    /**
     * a class which is used for doing some action after DealCard button has been pushed
     */
    private class DealCardListener implements ActionListener {
        /**
         * <b> Transformer </b> : Performing the action
         * <b> Pre Conditions </b> : None
         * <b> Post-Conditions </b> : performing the action
         */


        @Override
        public void actionPerformed(ActionEvent e) {

            Cards.readFile("resources/dealCards_greeklish.csv", "Deal");
            Cards.readFile("resources/mailCards.csv", "Mail");
            int x = Cards.dealCardCount++;
            if (Cards.dealCardCount == 20) {
                Cards.dealCardCount = 0;
            }
            x = new Random().nextInt(20); //for Random
            int n = Cards.showDealCard(x);
            if (n == JOptionPane.OK_OPTION) {
                int price = Integer.parseInt(PayDayCards.dealCards[x][3]);
                String message = PayDayCards.dealCards[x][2];
                int value = Integer.parseInt(PayDayCards.dealCards[x][4]);
                DealCard NewCard = new DealCard(price, message, value);
                if (plr1.getTurn()) {

                    plr1.addCardToStack(NewCard);
                    plr1.GiveOrTakeMoney(-1 * price);


                } else {
                    plr2.addCardToStack(NewCard);
                    plr2.GiveOrTakeMoney(-1 * price);

                }

            }
            repaintPlayerPanels();
            DealCardButton.setEnabled(false);

        }
    }

    /**
     * a class which is used for doing some action after EndTurn button has been pushed
     */

    private class EndTurnListener2 implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (plr2.getFinishedTurn()) {
                plr2.setTurn(false);
                plr1.setTurn(true);
                InfoBox.setText("Info Box" + "\n" + plr2.getNumberOfMonthsRemaining() + " Months Remaining " + "\n" + "Turn: " + game.Turn());
            }

        }
    }

    private class GetLoanListener2 implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (plr2.getTurn()) {
                plr2.AddLoan(900);
                plr2.GiveOrTakeMoney(1000);
                Loan2.setText("Loan: " + plr2.getLoan() + " Euro");
                Money2.setText("Money: " + plr2.getMoney() + " Euro");
            }

        }
    }

    private class RollDiceListener2 implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (plr2.getTurn() & !plr2.hasRolled()) {
                plr2.sethasRolled(true);
                plr1.sethasRolled(false);
                plr2.setFinishedTurn(true);
                plr1.setFinishedTurn(false);
                int steps = RollDice2();
                MovePawnB(steps);
                if (steps == 6) {
                    plr2.GiveOrTakeMoney(game.jp.getintLoot());
                    game.jp.setLoot(0);
                    JackpotText.setText("Jackpot: " + game.jp.getintLoot() + " Euro");
                    InfoBox.setText("Info Box" + "\n" + plr1.getNumberOfMonthsRemaining() + " Months Remaining " + "\n" + "Turn: " + game.Turn() + "\n" + "plr1 won the jackpot!");
                }

            } else {
                RollDice2();
            }

        }

    }

    private class MyDealCardsListener2 implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            JList list = new JList(plr2.PlayerCards().CardStackTolist().toArray());
            JOptionPane.showMessageDialog(
                    null, list, "Owned Deal Cards", JOptionPane.PLAIN_MESSAGE);


        }
    }


    private class EndTurnListener1 implements ActionListener {
        /**
         * <b> Transformer </b> : Performing the action
         * <b> Pre Conditions </b> : None
         * <b> Post-Conditions </b> : performing the action
         */


        @Override
        public void actionPerformed(ActionEvent e) {
            if (plr1.getFinishedTurn()) {
                plr1.setTurn(false);
                plr2.setTurn(true);
                InfoBox.setText("Info Box" + "\n" + plr1.getNumberOfMonthsRemaining() + " Months Remaining " + "\n" + "Turn: " + game.Turn());
            }

        }
    }

    /**
     * a class which is used for doing some action after GetLoan button has been pushed
     */
    private class GetLoanListener1 implements ActionListener {
        /**
         * <b> Transformer </b> : Performing the action
         * <b> Pre Conditions </b> : None
         * <b> Post-Conditions </b> : performing the action
         */


        @Override
        public void actionPerformed(ActionEvent e) {
            if (plr1.getTurn()) {
                plr1.AddLoan(900);
                plr1.GiveOrTakeMoney(1000);
                Loan1.setText("Loan: " + plr1.getLoan() + " Euro");
                Money1.setText("Money: " + plr1.getMoney() + " Euro");
            }
        }
    }


    /**
     * a class which is used for doing some action after RollDice button has been pushed
     */
    private class RollDiceListener1 implements ActionListener {
        /**
         * <b> Transformer </b> : Performing the action
         * <b> Pre Conditions </b> : None
         * <b> Post-Conditions </b> : performing the action
         */


        @Override
        public void actionPerformed(ActionEvent e) {
            if (plr1.getTurn() & !plr1.hasRolled()) {
                plr1.sethasRolled(true);
                plr2.sethasRolled(false);
                plr1.setFinishedTurn(true);
                plr2.setFinishedTurn(false);
                int steps = RollDice1();
                MovePawnA(steps);
                if (steps == 6) {
                    plr1.GiveOrTakeMoney(game.jp.getintLoot());
                    game.jp.setLoot(0);
                    JackpotText.setText("Jackpot: " + game.jp.getintLoot() + " Euro");
                    InfoBox.setText("Info Box" + "\n" + plr1.getNumberOfMonthsRemaining() + " Months Remaining " + "\n" + "Turn: " + game.Turn() + "\n" + "plr1 won the jackpot!");
                }

            } else {
                RollDice1();
            }

        }
    }

    /**
     * a class which is used for doing some action after MyDealCards button has been pushed
     */
    private class MyDealCardsListener1 implements ActionListener {
        /**
         * <b> Transformer </b> : Performing the action
         * <b> Pre Conditions </b> : None
         * <b> Post-Conditions </b> : performing the action
         */


        @Override
        public void actionPerformed(ActionEvent e) {

            JList list = new JList(plr1.PlayerCards().CardStackTolist().toArray());
            JOptionPane.showMessageDialog(
                    null, list, "Owned Deal Cards", JOptionPane.PLAIN_MESSAGE);
            System.out.println(Arrays.toString(list.getSelectedIndices()));
            Loan1.setText("Loan: " + plr1.getLoan() + " Euro");
        }
    }

    /**
     * <b> Transformer </b> : Moves the players position(pawn)
     * <b> Pre Conditions </b> : None
     * <b> Post-Conditions </b> : Moves the players pawn to new Position
     */

    public void MovePawnA(int steps) {
        int i = 1;
        int xCoords = PawnA.getLocation().x;
        int yCoords = PawnA.getLocation().y;

        MainPanel.remove(PawnA);
        while (i <= steps) {
            if (xCoords > 900) {
                xCoords = 50;
                yCoords += 165;
            } else if (xCoords == 485 && yCoords == 910) {
                break;
            } else {

                xCoords += 145;

            }
            position1++;
            i++;

        }
        if (position1 == 4 || position1 == 11 || position1 == 18 || position1 == 25) {
            ThursdayRise();
        }
        if (position1 % 7 == 0) {
            SundayFootBallDay();
        }

        PawnA = CreatePlayerPawnA();
        PawnA.setVisible(true);
        MainPanel.add(PawnA, JLayeredPane.POPUP_LAYER);
        PawnA.setLocation(xCoords, yCoords);
        positionActions(plr1);
        MainPanel.repaint();
    }

    public void MovePawnB(int steps) {
        int i = 1;
        int xCoords = PawnB.getLocation().x;
        int yCoords = PawnB.getLocation().y;

        MainPanel.remove(PawnB);

        while (i <= steps) {
            if (xCoords > 900) {
                xCoords = 50;
                yCoords += 165;
            } else if (xCoords == 485 && yCoords == 910) {
                break;
            } else {

                xCoords += 145;

            }
            position2++;
            i++;

        }
        if (position2 == 4 || position2 == 11 || position2 == 18 || position2 == 25) {
            ThursdayRise();
        }

        if (position2 % 7 == 0) {
            SundayFootBallDay();
        }


        PawnB = CreatePlayerPawnB();
        PawnB.setVisible(true);
        MainPanel.add(PawnB, JLayeredPane.POPUP_LAYER);
        PawnB.setLocation(xCoords, yCoords);
        positionActions(plr2);
        MainPanel.repaint();

    }


    /**
     * <b> Transformer </b> : Creates the players pawn
     * <b> Pre Conditions </b> : None
     * <b> Post-Conditions </b> : Creates pawn
     */


    public JLabel CreatePlayerPawnA() {
        //player A
        JLabel PawnA = new JLabel();
        PawnA.setSize(60, 60);
        Image BluePawn = new ImageIcon(cldr.getResource("resources/images/pawn_blue.png")).getImage();
        BluePawn = BluePawn.getScaledInstance(50, 50, Image.SCALE_SMOOTH);
        PawnA.setIcon(new ImageIcon(BluePawn));
        PawnA.setVisible(true);
        return PawnA;

    }

    public JLabel CreatePlayerPawnB() {
        //player B
        JLabel PawnB = new JLabel();
        PawnB.setSize(60, 60);
        Image YellowPawn = new ImageIcon(cldr.getResource("resources/images/pawn_yellow.png")).getImage();
        YellowPawn = YellowPawn.getScaledInstance(50, 50, Image.SCALE_SMOOTH);
        PawnB.setIcon(new ImageIcon(YellowPawn));
        PawnB.setVisible(true);
        return PawnB;

    }

    /**
     * <b> Transformer </b> : Performing the actions depending on the position the player is at
     * <b> Pre Conditions </b> : None
     * <b> Post-Conditions </b> : performing the position's action
     */

    public void positionActions(Player plr1or2) {
        String PawnAorB;


        if (plr1or2 == plr1) {
            PawnAorB = "PawnA";
        } else {
            PawnAorB = "PawnB";
        }

        Position CurrentPos = GetPawnPosition(PawnAorB);
        if (CurrentPos instanceof BuyerPos) {
            if (!plr1or2.PlayerCards().isEmpty()) {
                JList list = new JList(plr1or2.PlayerCards().CardStackTolist().toArray());
                JOptionPane.showMessageDialog(
                        null, list, "Choose card to sell", JOptionPane.PLAIN_MESSAGE);
                String a = (Arrays.toString(list.getSelectedIndices()));
                a = removeFirstandLast(a);
                int b = Integer.parseInt(a);
                plr1or2.SellCard(plr1or2.PlayerCards().getCard(b));
                InfoBox.setText("Info Box" + "\n" + plr1or2.getNumberOfMonthsRemaining() + " Months Remaining" + "\n" + "Turn :" + game.Turn() + "\n" + "Plr1 Choose a Card to Sell");
            } else {
                InfoBox.setText("Info Box" + "\n" + plr1or2.getNumberOfMonthsRemaining() + " Months Remaining" + "\n" + "Turn :" + game.Turn() + "\n" + "Plr1 You do not own any DealCards");
                JOptionPane.showMessageDialog(null, plr1or2.getName() + " You do not own any DealCards", "No DealCards", JOptionPane.PLAIN_MESSAGE);
            }
        } else if (CurrentPos instanceof DealPos) {
            DealCardButton.setEnabled(true);
            InfoBox.setText("Info Box" + "\n" + plr1or2.getNumberOfMonthsRemaining() + " Months Remaining" + "\n" + "Turn :" + game.Turn() + "\n" + plr1or2 + " Draw a Deal Card!");
        } else if (CurrentPos instanceof FamilyCasinoPos) {
            if (diceRoll1 == 0 || diceRoll1 == 3 || diceRoll1 == 5) {
                plr1or2.GiveOrTakeMoney(-500);
                game.jp.AddLoot(500);
                InfoBox.setText("Info Box" + "\n" + plr1or2.getNumberOfMonthsRemaining() + " Months Remaining" + "\n" + "Turn :" + game.Turn() + "\n" + plr1or2.getName() + " You Paid 500 Euro to Jackpot!");
            } else {
                plr1or2.GiveOrTakeMoney(500);
                InfoBox.setText("Info Box" + "\n" + plr1or2.getNumberOfMonthsRemaining() + " Months Remaining" + "\n" + "Turn :" + game.Turn() + "\n" + plr1or2.getName() + " You Won 500 Euro from the Bank");
            }
        } else if (CurrentPos instanceof MessagePos) {
            MailCardButton.setEnabled(true);
            InfoBox.setText("Info Box" + "\n" + plr1or2.getNumberOfMonthsRemaining() + " Months Remaining" + "\n" + "Turn :" + game.Turn() + "\n" + plr1or2.getName() + " Draw a Mail Card!");
        } else if (CurrentPos instanceof PayDayPosition) {
            if (plr1or2.getNumberOfMonthsRemaining()>0) {
                plr1or2.GiveOrTakeMoney(3500);
                plr1or2.GiveOrTakeMoney(-1 * plr1or2.getBill());
                plr1or2.setBill(0);
                plr1or2.GiveOrTakeMoney((int) (0.1 * plr1or2.getMoney()));
                Object[] possibilities = new Object[plr1or2.getLoan() / 1000];
                plr1or2.setNumberOfMonthsRemaining(plr1or2.getNumberOfMonthsRemaining() - 1);
                for (int i = 0; i < possibilities.length; i++) {
                    possibilities[i] = (i + 1) * 1000;
                }
                if (plr1or2.getLoan() > 0) {
                    int s = (int) JOptionPane.showInputDialog(
                            null,
                            "Input the amount of money you want to pay for the loan: ",
                            "Loan Payment",
                            JOptionPane.PLAIN_MESSAGE,
                            null,
                            possibilities,
                            null);
                    plr1or2.GiveOrTakeMoney(-1 * s);
                    plr1or2.setLoan(plr1or2.getLoan() - s);
                }
                plr1or2.PlayerCards().ResetCardStack();
            }
            if (plr1or2 == plr1) {
                if (plr1.getNumberOfMonthsRemaining() > 0) {
                    PawnA.setLocation(50, 250);
                    position1 = 0;
                }
            } else if (plr1or2==plr2){
                if (plr2.getNumberOfMonthsRemaining() > 0) {
                    PawnB.setLocation(50, 250);
                    position2 = 0;
                }
            }


            if (plr1or2.getNumberOfMonthsRemaining() == 0 && plr1or2.getOpponent().getNumberOfMonthsRemaining() == 0) {
                endGame();
                RollDice1.setEnabled(true);
                RollDice2.setEnabled(true);
            }

            MainPanel.repaint();


        } else if (CurrentPos instanceof RadioContestPos) {
            Random rand = new Random();
            int roll1 = 0;
            int roll2 = 0;
            while (roll1 == roll2) {
                roll1 = rand.nextInt(5) + 1;
                roll2 = rand.nextInt(5) + 1;
                JOptionPane.showMessageDialog(null, "plr1 rolled :" + roll1, "Radio Contest", JOptionPane.PLAIN_MESSAGE);
                JOptionPane.showMessageDialog(null, "plr2 rolled :" + roll2, "Radio Contest", JOptionPane.PLAIN_MESSAGE);
                if (roll1 > roll2) {
                    plr1.GiveOrTakeMoney(1000);
                    JOptionPane.showMessageDialog(null, "Plr1 Won!" + "\n" + "Lucky roll " + roll1, "Radio Contest", JOptionPane.PLAIN_MESSAGE);
                } else if (roll2 > roll1) {
                    plr2.GiveOrTakeMoney(1000);
                    JOptionPane.showMessageDialog(null, "Plr2 Won" + "\n" + "Lucky roll " + roll2, "Radio Contest", JOptionPane.PLAIN_MESSAGE);
                }
            }

        } else if (CurrentPos instanceof RafflePos) {
            Object[] possibilities = new Object[6];
            for (int i = 0; i < possibilities.length; i++) {
                possibilities[i] = i + 1;
            }
            int plr1Choice = 0;
            int plr2Choice = -1;
            int num = 100;
            while (plr1Choice != num && plr2Choice != num && plr1Choice != plr2Choice) {
                plr1Choice = (int) JOptionPane.showInputDialog(
                        null,
                        plr1or2.getName() + " Input a number between 1 - 6:",
                        "Lottery",
                        JOptionPane.PLAIN_MESSAGE,
                        null,
                        possibilities,
                        possibilities[0]);
                plr2Choice = (int) JOptionPane.showInputDialog(
                        null,
                        plr1or2.getOpponent().getName() + "Input a number between 1 - 6:",
                        "Lottery",
                        JOptionPane.PLAIN_MESSAGE,
                        null,
                        possibilities,
                        possibilities[1]);
                Random rand = new Random();
                num = rand.nextInt(6) + 1;
                ImageIcon dice = new ImageIcon(cldr.getResource("resources/images/dice-" + num + ".png"));
                JOptionPane.showMessageDialog(null, "Lucky number: " + num, "Lottery", JOptionPane.PLAIN_MESSAGE, dice);
            }
            if (plr1Choice == num) {
                plr1or2.GiveOrTakeMoney(1000);
                InfoBox.setText("Info Box" + "\n" + plr1or2.getNumberOfMonthsRemaining() + " Months Remaining" + "\n" + "Turn :" + game.Turn() + "\n" + plr1or2.getName() + " won the lottery!");
            } else {
                plr1or2.getOpponent().GiveOrTakeMoney(1000);
                InfoBox.setText("Info Box" + "\n" + plr1or2.getNumberOfMonthsRemaining() + " Months Remaining" + "\n" + "Turn :" + game.Turn() + "\n" + plr1or2.getOpponent().getName() + " won the lottery!");
            }
        } else if (CurrentPos instanceof SweepstakesPos) {

            if (plr1or2 == plr1) {
                RollDice1();
                plr1or2.GiveOrTakeMoney(1000 * diceRoll1);
                InfoBox.setText("Info Box" + "\n" + plr1or2.getNumberOfMonthsRemaining() + " Months Remaining" + "\n" + "Turn :" + game.Turn() + "\n" + "Plr1 You Won " + 1000 * diceRoll1 + " Euro from Sweepstakes.");


            } else {
                RollDice2();
                plr2.GiveOrTakeMoney(1000 * diceRoll2);
                InfoBox.setText("Info Box" + "\n" + plr1or2.getNumberOfMonthsRemaining() + " Months Remaining" + "\n" + "Turn :" + game.Turn() + "\n" + "Plr1 You Won " + 1000 * diceRoll2 + " Euro from Sweepstakes.");
            }
        } else if (CurrentPos instanceof YardSalePos) {
            if (plr1or2 == plr1) {
                RollDice1();
                plr1.GiveOrTakeMoney(-1 * diceRoll1 * 100);
                Random rand = new Random();
                int i = rand.nextInt(10);
                String msg = Cards.dealCards[i][2];
                int price = Integer.parseInt(Cards.dealCards[i][3]);
                int value = Integer.parseInt(Cards.dealCards[i][4]);
                DealCard newDeal = new DealCard(price, msg, value);
                plr1.PlayerCards().addCard(newDeal);
                InfoBox.setText("Info Box" + "\n" + plr1or2.getNumberOfMonthsRemaining() + " Months Remaining" + "\n" + "Turn :" + game.Turn() + "\n" + "Plr1" + " " + msg + " me twn tsampa");
            } else {
                RollDice2();
                plr2.GiveOrTakeMoney(-1 * diceRoll1 * 100);
                Random rand = new Random();
                int i = rand.nextInt(10);
                String msg = Cards.dealCards[i][2];
                int price = Integer.parseInt(Cards.dealCards[i][3]);
                int value = Integer.parseInt(Cards.dealCards[i][4]);
                DealCard newDeal = new DealCard(price, msg, value);
                plr2.PlayerCards().addCard(newDeal);
                InfoBox.setText("Info Box" + "\n" + plr1or2.getNumberOfMonthsRemaining() + " Months Remaining" + "\n" + "Turn :" + game.Turn() + "\n" + "Plr2" + " " + msg + " me twn tsampa");
            }
        }

        repaintPlayerPanels();

    }


    public int RollDice1() {
        Random rand = new Random();
        int roll = rand.nextInt(6) + 1;
        JPanel newDice = new JPanel();
        newDice = CreateDice(roll);
        MainPanel.remove(Dice1);
        MainPanel.add(newDice, JLayeredPane.POPUP_LAYER);
        Dice1 = newDice;
        Dice1.setVisible(true);
        Dice1.setLocation(1300, 200);
        diceRoll1 = roll;
        return roll;

    }

    public int RollDice2() {
        Random rand = new Random();
        int roll = rand.nextInt(6) + 1;
        JPanel newDice = new JPanel();
        newDice = CreateDice(roll);
        MainPanel.remove(Dice2);
        MainPanel.add(newDice, JLayeredPane.POPUP_LAYER);
        Dice2 = newDice;
        Dice2.setVisible(true);
        Dice2.setLocation(1300, 825);
        diceRoll2 = roll;
        return roll;

    }

    public Position GetPawnPosition(String PawnAorB) {
        Position CurrentPos;
        if (PawnAorB.equals("PawnA")) {
            CurrentPos = board[position1];

        } else {
            CurrentPos = board[position2];
        }

        return CurrentPos;
    }

    public static String removeFirstandLast(String str) {

        // Removing first and last character
        // of a string using substring() method
        str = str.substring(1, str.length() - 1);

        // Return the modified string
        return str;
    }

    public void repaintPlayerPanels() {
        Money1.setText("Money: " + plr1.getMoney() + " Euro");
        Money2.setText("Money: " + plr2.getMoney() + " Euro");
        Loan1.setText("Loan: " + plr1.getLoan() + " Euro");
        Loan2.setText("Loan: " + plr2.getLoan() + " Euro");
        Bills1.setText("Bill: " + plr1.getBill() + " Euro");
        Bills2.setText("Bill: " + plr2.getBill() + " Euro");
        JackpotText.setText("Jackpot: " + game.jp.getLoot());

    }

    public void ThursdayRise() {
        String[] options = new String[]{"Bet", "Not Interested"};
        Random rand = new Random();
        int result = RollDice1();
        int response = JOptionPane.showOptionDialog(null, "Are you willing to bet on Crypto", "Thursday Rise",
                JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE,
                null, options, options[0]);
        if (response != 1) {
            if (result == 1 | result == 2) {
                if (plr1.getTurn()) {
                    plr1.GiveOrTakeMoney(-300);
                } else {
                    plr2.GiveOrTakeMoney(-300);
                }
                JOptionPane.showMessageDialog(null, "You Lost your money!", "Thursday Rise", JOptionPane.PLAIN_MESSAGE);
            } else if (result == 3 | result == 4) {
                JOptionPane.showMessageDialog(null, "You got your money back!", "Thursday Rise", JOptionPane.PLAIN_MESSAGE);
            } else {
                if (plr1.getTurn()) {
                    plr1.GiveOrTakeMoney(300);
                } else {
                    plr2.GiveOrTakeMoney(300);
                }
                JOptionPane.showMessageDialog(null, "You doubled your money!", "Thursday Rise", JOptionPane.PLAIN_MESSAGE);

            }
        }

    }


    public void SundayFootBallDay() {
        String[] options = new String[]{"Barcelona will win", "Draw", "Real will win", "Not interested"};
        Random rand = new Random();
        int result = RollDice1();
        int response = JOptionPane.showOptionDialog(null, "Will you Bet 500 Euros for today's match?", "Sunday Football Game",
                JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE,
                null, options, options[0]);
        if (response != 3) {
            if (result == 1 | result == 2) {
                if (response == 1) {
                    JOptionPane.showMessageDialog(null, "You won the Bet!", "Sunday Match", JOptionPane.PLAIN_MESSAGE);
                    if (plr1.getTurn()) {
                        plr1.GiveOrTakeMoney(1000);
                    } else {
                        plr2.GiveOrTakeMoney(1000);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "You Lost the Bet!", "Sunday Match", JOptionPane.PLAIN_MESSAGE);
                    if (plr1.getTurn()) {
                        plr1.GiveOrTakeMoney(-500);
                    } else {
                        plr2.GiveOrTakeMoney(-500);
                    }
                }
            } else if (result == 3 | result == 4) {
                if (response == 1) {
                    JOptionPane.showMessageDialog(null, "You won the Bet!", "Sunday Match", JOptionPane.PLAIN_MESSAGE);
                    if (plr1.getTurn()) {
                        plr1.GiveOrTakeMoney(1000);
                    } else {
                        plr2.GiveOrTakeMoney(1000);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "You Lost the Bet!", "Sunday Match", JOptionPane.PLAIN_MESSAGE);
                    if (plr1.getTurn()) {
                        plr1.GiveOrTakeMoney(-500);
                    } else {
                        plr2.GiveOrTakeMoney(-500);
                    }
                }
            } else {
                if (response == 2) {
                    JOptionPane.showMessageDialog(null, "You won the Bet!", "Sunday Match", JOptionPane.PLAIN_MESSAGE);
                    if (plr1.getTurn()) {
                        plr1.GiveOrTakeMoney(1000);
                    } else {
                        plr2.GiveOrTakeMoney(1000);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "You Lost the Bet!", "Sunday Match", JOptionPane.PLAIN_MESSAGE);
                    if (plr1.getTurn()) {
                        plr1.GiveOrTakeMoney(-500);
                    } else {
                        plr2.GiveOrTakeMoney(-500);
                    }
                }

            }
        }

    }

    public void endGame() {
        JOptionPane.showMessageDialog(
                null,
                game.Winner().getName() + " Won the Game!",
                "WINNER",
                JOptionPane.PLAIN_MESSAGE);

    }

}
