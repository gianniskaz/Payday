package Controller;

import Model.Cards.CardStacks.*;
import Model.Jackpot;
import Model.Player;
import Model.Positions.PayDayPosition;
import Model.Positions.*;

import java.util.ArrayList;
import java.util.Random;

public class Controller {
    public Player Player1;
    public Player Player2;
    public MailCardStack MailCards;
    public DealCardsStack DealCards;
    public RejectedCards Rejects;
    public Jackpot jp;
    public CardStacks Player1Cards;
    public CardStacks Player2Cards;
    public int plr1Score;
    public int plr2Score;
    public Position[] board;


    /**
     * <b> Constructor </b>: Creates a new Controller
     * <b> Pre-Conditions </b>:None
     * <b> Post-Conditions </b>: initializes players , card stacks
     */
    public Controller() {
        Player1 = new Player("plr1");
        Player2 = new Player("plr2");
        Player1.setOpponent(Player2);
        Player2.setOpponent(Player1);
        MailCards = new MailCardStack();
        DealCards = new DealCardsStack();
        Player1Cards = new CardStacks();
        Player2Cards = new CardStacks();
        jp = new Jackpot();
        board = new Position[32];

        Player1.setMoney(0);
        Player2.setMoney(0);
        NewGame();


    }


    /**
     * <b> Transformer </b>:
     * <b> Pre-Conditions </b>:None
     * <b> Post-Conditions </b>: initializes the game
     */
    public void NewGame() {
        init_board();
        Player1.GiveOrTakeMoney(3500);
        Player2.GiveOrTakeMoney(3500);

    }

    /**
     * <b> Transformer </b>: Creates the board with the positions in random order
     * <b> Pre-Conditions </b>:None
     * <b> Post-Conditions </b>: creates board with random position order except
     * the payday position
     */
    public Position[] init_board() {
        board[0] = new StartPos("resources/images/start.png");
        board[31] = new PayDayPosition("resources/images/pay.png");
        ArrayList<Integer> AvailableIndexes = new ArrayList<Integer>();
        Random rand = new Random();

        for (int j = 1; j <= 30; j++) {
            AvailableIndexes.add(j);
        }
        int i = 1;
        //Message Positions for 1 card drawn
        while (i <= 4) {
            int nextIndex = rand.nextInt(AvailableIndexes.size());
            int boardIndex = AvailableIndexes.get(nextIndex);
            board[boardIndex] = new MessagePos("resources/images/mc1.png", boardIndex, 1);
            AvailableIndexes.remove(Integer.valueOf(boardIndex));
            i++;
        }

        //Message Positions for 2 cards drawn
        i = 1;
        while (i <= 4) {
            int nextIndex = rand.nextInt(AvailableIndexes.size());
            int boardIndex = AvailableIndexes.get(nextIndex);
            board[boardIndex] = new MessagePos("resources/images/mc2.png", boardIndex, 2);
            AvailableIndexes.remove(Integer.valueOf(boardIndex));
            i++;
        }

        //Deal Positions
        i = 1;
        while (i <= 5) {
            int nextIndex = rand.nextInt(AvailableIndexes.size());
            int boardIndex = AvailableIndexes.get(nextIndex);
            board[boardIndex] = new DealPos("resources/images/deal.png", boardIndex);
            AvailableIndexes.remove(Integer.valueOf(boardIndex));
            i++;
        }
        //sweepstakes position
        i = 1;
        while (i <= 2) {
            int nextIndex = rand.nextInt(AvailableIndexes.size());
            int boardIndex = AvailableIndexes.get(nextIndex);
            board[boardIndex] = new SweepstakesPos("resources/images/sweep.png", boardIndex);
            AvailableIndexes.remove(Integer.valueOf(boardIndex));
            i++;
        }
        //Raffle position
        i = 1;
        while (i <= 3) {
            int nextIndex = rand.nextInt(AvailableIndexes.size());
            int boardIndex = AvailableIndexes.get(nextIndex);
            board[boardIndex] = new RafflePos("resources/images/lottery.png", boardIndex);
            AvailableIndexes.remove(Integer.valueOf(boardIndex));
            i++;
        }
        //Radio contest position
        i = 1;
        while (i <= 2) {
            int nextIndex = rand.nextInt(AvailableIndexes.size());
            int boardIndex = AvailableIndexes.get(nextIndex);
            board[boardIndex] = new RadioContestPos("resources/images/radio.png", boardIndex);
            AvailableIndexes.remove(Integer.valueOf(boardIndex));
            i++;
        }
        //Buyer position
        i = 1;
        while (i <= 6) {
            int nextIndex = rand.nextInt(AvailableIndexes.size());
            int boardIndex = AvailableIndexes.get(nextIndex);
            board[boardIndex] = new BuyerPos("resources/images/buyer.png", boardIndex);
            AvailableIndexes.remove(Integer.valueOf(boardIndex));
            i++;
        }
        //Family Casino night position
        i = 1;
        while (i <= 2) {
            int nextIndex = rand.nextInt(AvailableIndexes.size());
            int boardIndex = AvailableIndexes.get(nextIndex);
            board[boardIndex] = new FamilyCasinoPos("resources/images/casino.png", boardIndex);
            AvailableIndexes.remove(Integer.valueOf(boardIndex));
            i++;
        }
        //Yard Sale position
        i = 1;
        while (i <= 2) {
            int nextIndex = rand.nextInt(AvailableIndexes.size());
            int boardIndex = AvailableIndexes.get(nextIndex);
            board[boardIndex] = new YardSalePos("resources/images/yard.png", boardIndex);
            AvailableIndexes.remove(Integer.valueOf(boardIndex));
            i++;
        }
        return board;
    }



    /**
     * <b> Transformer </b>: Randomly chooses between the 2 players the one that will start first
     * <b> Pre-Conditions </b>:None
     * <b> Post-Conditions </b>: Choosing First player
     */
    public void SetFirstPlayer() {
        Random rand = new Random();
        int turn;
        turn = rand.nextInt(2);
        if (turn == 1) {
            Player1.setTurn(true);
            Player2.setTurn(false);
        } else {
            Player1.setTurn(false);
            Player2.setTurn(true);
        }
    }


    /**
     * <b> Accessor </b>: returns True/False if the player won or lost the bet respectively
     * <b> Pre-Conditions </b>:None
     * <b> Post-Conditions </b>:checks if the day is sunday
     */

    public boolean isSunday() {
        return Position.getDayName() == "Sunday";

    }




    /**
     * <b> Accessor </b>: returns the final score of the players in a 2d array
     * <b> Pre-Conditions </b>:None
     * <b> Post-Conditions </b>: uses methods in abstract class player to get score
     */
    public int[] FinalScore() {
        int[] score = new int[2];
        score[0] = Player1.getScore();
        score[1] = Player2.getScore();
        return score;
    }

    /**
     * <b> Accessor </b>:Returns the player that won
     * <b> Pre-Conditions </b>:None
     * <b> Post-Conditions </b>: returns Winner
     */
    public Player Winner() {
        Player1.setMoney(Player1.getMoney() - Player1.getLoan());
        Player2.setMoney(Player2.getMoney() - Player2.getLoan());
        if (Player1.getMoney() > Player2.getMoney()) {
            return Player1;
        } else {
            return Player2;
        }

    }

    /**
     * <b> Accessor </b>: Checks if the game has reached its end
     * <b> Pre-Conditions </b>:None
     * <b> Post-Conditions </b>: returns true or false depending on the status of the game
     */
    public boolean GameFinished() {
        return (Player1.getNumberOfMonthsRemaining() == 0 & Player2.getNumberOfMonthsRemaining() == 0);
    }

    /**
     * <b> Accessor </b>: Creates a string with info about the players
     * <b> Pre-Conditions </b>:None
     * <b> Post-Conditions </b>: Returns String containing info about the game
     * for example players turn, rounds left(months)
     */
    public String InfoBox() {
        String info = "INFO BOX" + "\n" + "Months remaining: " + Player1.getNumberOfMonthsRemaining() + "\n" + "Turn: ";
        if (Player1.getTurn()) {
            info += Player1.getName() + "\n" + Player1.getPosition();


        } else {
            info += Player2.getName() + "\n" + Player2.getPosition();
        }
        return info;
    }



    public Player Turn() {
        if (Player1.getTurn()) {
            return Player1;
        } else {
            return Player2;
        }
    }
}

